package com.cn.bugreport

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.cn.bugreport.models.Bugreport
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_bugreport.*

class BugreportActivity : AppCompatActivity() {

    companion object {
        val TAG = "BugreportActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bugreport)

        supportActionBar?.title = "Add Bugreport"
        save_button_bugreport.setOnClickListener {
            val title = title_edittext_bugreport.text.toString()
            val content = content_edittext_bugreport.text.toString()

            if (title.isEmpty() || content.isEmpty()) return@setOnClickListener

            val reporterId = FirebaseAuth.getInstance().uid

            val reference = FirebaseDatabase.getInstance().getReference("/bugreports").push()

            val bugreport = Bugreport(reference.key!!, reporterId!!, title, content, System.currentTimeMillis() / 1000)
            reference.setValue(bugreport)
                .addOnSuccessListener {
                    Log.d(TAG, "Saved our bugreport: ${reference.key}")
                    finish()
                }
        }
    }
}